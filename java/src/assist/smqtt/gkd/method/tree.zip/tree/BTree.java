package assist.smqtt.gkd.method.tree;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;

import org.zoolu.util.Bytes;
import org.zoolu.util.Range;


public class BTree {

	TNode root;
	BTree left, right;

	static MessageDigest hash;
	
	static {
		try {
			hash= MessageDigest.getInstance("SHA256");
		}
		catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}
	

	public BTree(byte[] val) {
		root= new TNode(0,0,val);
	}
	
	public BTree(TNode node) {
		root= node;
	}
	
	public void fill(int depth) {
		if (root.dep<depth) {
			left= new BTree(new TNode(root.dep+1, 2*root.pos, f0(root.val)));
			left.fill(depth);
			right= new BTree(new TNode(root.dep+1,2*root.pos+1,f1(root.val)));
			right.fill(depth);
		}
	}
	
	private static byte[] f0(byte[] x) {
		var y= hash.digest(x);
		if (x.length<y.length) y= Bytes.copy(y,0,x.length);
		return y;
	}
	
	private static byte[] f1(byte[] x) {
		x[0]^= 0x01;
		var y= f0(x);
		x[0]^= 0x01;
		return y;
	}
	

	private void visit(Consumer<BTree> consumer) {
		consumer.accept(this);
		if (left!=null)	left.visit(consumer);
		if (right!=null) right.visit(consumer);
	}


	public ArrayList<TNode> leaves() {
		var list= new ArrayList<TNode>();
		visit((BTree bt)->{if (bt.left==null && bt.right==null) list.add(bt.root);});
		return list;
	}

	
	public ArrayList<TNode> nodes() {
		var list= new ArrayList<TNode>();
		visit((BTree bt)->list.add(bt.root));
		return list;
	}
	
	
	public ArrayList<TNode> bestCover(Set<TNode> nodeSet) {
		var coverList= new ArrayList<TNode>();
		bestCover(nodeSet,coverList);
		return coverList;
	}
	
	
	public ArrayList<TNode> bestCover(int begin, int end) {
		var allLeaves= leaves();
		var intervalSubset= new HashSet<TNode>();
		for (int i: new Range(begin,end)) intervalSubset.add(allLeaves.get(i));
		return bestCover(intervalSubset);
	}

	
	private void bestCover(Set<TNode> nodeSet, ArrayList<TNode> coverList) {
		var leaves= leaves();
		//System.out.println("DEBUG: "+root+"("+leaves.size()+")");
		boolean success= true;
		for (var leaf: leaves) {
			if (!nodeSet.contains(leaf)) {
				success= false;
				break;
			}
		}
		if (success) coverList.add(root);
		else {
			if (left!=null) left.bestCover(nodeSet,coverList);
			if (right!=null) right.bestCover(nodeSet,coverList);
		}
	}


	@Override
	public String toString() {
		var sb= new StringBuffer();
		visit((BTree bt)->{
			if (sb.length()>0) sb.append(", ");
			sb.append(bt.root.toString());
		});
		return sb.toString();
	}
}
