package assist.smqtt.gkd.method.tree;

import org.zoolu.util.Bytes;


public class TNode {
	
	protected TNode() {
	}

	public TNode(int dep, int pos, byte[] val) {
		this.dep= dep;
		this.pos= pos;
		this.val= val;
	}

	public TNode(TNode value) {
		this.dep= value.dep;
		this.pos= value.pos;
		this.val= value.val;
	}

	public int dep;
	public int pos;
	public byte[] val;
	
	@Override
	public String toString() {
		return "X["+dep+","+pos+"]:"+Bytes.toHex(val);
	}
}
